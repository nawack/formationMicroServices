aller dans configLocal et faire un clone de 

```
git clone https://github.com/olivierlaporte/configuration.git
```

