## Prerequis 
Maven 3.2.0 ou + 
Docker
Docker-Compose

# Docker
mvn clean install && 
/opt/bin/docker-compose up 
