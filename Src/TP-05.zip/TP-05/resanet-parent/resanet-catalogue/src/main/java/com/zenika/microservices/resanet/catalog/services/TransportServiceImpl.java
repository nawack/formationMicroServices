package com.zenika.microservices.resanet.catalog.services;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.zenika.microservices.resanet.catalog.domain.Transport;
import com.zenika.microservices.resanet.catalog.repository.TransportRepository;

@Service
public class TransportServiceImpl implements TransportService {

	private TransportRepository transportRepository;
	
	@Inject
	public TransportServiceImpl(final TransportRepository transportRepository) {
		this.transportRepository = transportRepository;
	}

	@Override
	public String ajouterTransport(Transport transport) {
		Transport t = transportRepository.save(transport);
		return t.getId();
	}

	@Override
	public List<Transport> findAll() {
		return Lists.newArrayList(transportRepository.findAll());
	}
	
}
