package com.zenika.microservices.resanet.reservations.filter;


import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

@Component
public class CorrelationHeaderFilter implements Filter {
    private static final String CORRELATION_ID_HEADER = "CORRELATION_ID";

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        final HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        String currentCorrId = httpServletRequest.getHeader(CORRELATION_ID_HEADER);
        if (currentCorrId == null) {
            currentCorrId = UUID.randomUUID().toString();
        }
        MDC.put(CORRELATION_ID_HEADER, currentCorrId);
        final HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
        httpServletResponse.setHeader(CORRELATION_ID_HEADER, currentCorrId);
        filterChain.doFilter(httpServletRequest, servletResponse);
    }

}