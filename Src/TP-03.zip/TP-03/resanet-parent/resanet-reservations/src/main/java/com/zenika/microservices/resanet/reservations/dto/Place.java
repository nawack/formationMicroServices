package com.zenika.microservices.resanet.reservations.dto;

public class Place {

	private String classe;
	
	private String seat;

	public String getClasse() {
		return classe;
	}

	public void setClasse(String classe) {
		this.classe = classe;
	}

	public String getSeat() {
		return seat;
	}

	public void setSeat(String seat) {
		this.seat = seat;
	}
	
	
}
