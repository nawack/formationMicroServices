package com.zenika.microservices.resanet.reservations.handler;


//TODO 11
public class MessageHandler /*implements MessageLister */{

	/*
	@Override
    public void onMessage(Message message) {
		
		
	}
	*/
}
