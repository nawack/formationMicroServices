package com.zenika.microservices.resanet.catalog.starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;


public class Application  {

    public static void main(final String[] args) {
        SpringApplication.run(Application.class, args);
    }

    
}
