package com.zenika.microservices.resanet;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.zenika.microservices.resanet.domain.Ville;

import static org.junit.Assert.*;

//TODO 08 Mettre les annotations pour utiliser JUnitSpring4 et setup le contexte
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration
public class VilleTest {

	//TODO 09 : Créer le RestTemplate
	private RestTemplate restTemplate;
	
	//TODO 10 décommenter @Test
	//@Test
	public void testGetList(){
		//List<Ville> villes = restTemplate. ...
				
		//assertEquals(4, villes.size());
	}
	
	//TODO 11
	//@Test
	public void testGetId(){
		//Ville ville = restTemplate.
		
		
		//assertEquals("Paris",ville.getName())
	}

	//TODO 13 : Utiliser le restTemplate pour créer une ville
	//@Test
	public void testCreateVille(){
		Ville ville = new Ville();
		ville.setNom("Brest");
		
				
		//restTemplate. faire le post
				
				
		//assertNotNull(ville.getId()) //Signifie que c'est une ville
	}
	
	
	//TODO 13 : Utiliser le restTemplate pour créer une ville
	//@Test
	public void testUpdateVille(){
		Ville ville = new Ville();
		ville.setNom("Brest");
		
				
		//restTemplate. faire le post
				
				
		//assertNotNull(ville.getId()) //Signifie que c'est une ville
	}
}
