#!/bin/bash
java -classpath "./h2-1.4.191.jar" org.h2.tools.Server

