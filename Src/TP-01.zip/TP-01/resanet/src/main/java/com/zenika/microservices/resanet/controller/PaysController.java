package com.zenika.microservices.resanet.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PaysController {

	
	
}
