package com.zenika.microservices.resanet.controller;

import java.util.List;


@CrossOrigin
@RestController
@RequestMapping("/transport")
public class TransportController {

	private final TransportRepository transportRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(TransportController.class);
	
	
	@Inject
	public TransportController(TransportRepository transportRepository){
		this.transportRepository = transportRepository;
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public List<Transport> readTransports() {
		return transportRepository.findAll();
	}
	
	@RequestMapping(value = "/{transportId}", method = RequestMethod.GET)
	public Transport readTransports(@PathVariable Long transportId) {
		return transportRepository.findOne(transportId);
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<Transport> addTransport(@RequestBody Transport transport) {
		transport = transportRepository.save(transport);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setLocation(ServletUriComponentsBuilder
				.fromCurrentRequest().path("/{id}")
				.buildAndExpand(transport.getId()).toUri());
		

        return new ResponseEntity<>(null, httpHeaders, HttpStatus.CREATED);
	}
	
	
	
}